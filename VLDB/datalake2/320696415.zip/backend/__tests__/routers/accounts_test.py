from backend.database.schema import DBAccount


def test_get_accounts_in_order(session, client):
    session.add(DBAccount(username="account1", email="account1@gmail.com",
                hashed_password="I love plaintext pw storing"))
    session.add(DBAccount(username="account2", email="account2@gmail.com",
                hashed_password="I love plaintext pw storing"))
    session.add(DBAccount(username="account3", email="account3@gmail.com",
                hashed_password="I love plaintext pw storing"))
    session.commit()
    response = client.get("/accounts")
    assert response.status_code == 200
    assert response.json() == {
        "metadata": {"count": 3},
        "accounts": [
            {"id": 1, "username": "account1"},
            {"id": 2, "username": "account2"},
            {"id": 3, "username": "account3"},
        ]
    }


def test_get_accounts_not_in_order(session, client):
    session.add(DBAccount(username="account1", email="account1@gmail.com",
                hashed_password="I love plaintext pw storing", id=3))
    session.add(DBAccount(username="account2", email="account2@gmail.com",
                hashed_password="I love plaintext pw storing", id=2))
    session.add(DBAccount(username="account3", email="account3@gmail.com",
                hashed_password="I love plaintext pw storing", id=1))
    session.commit()
    response = client.get("/accounts")
    assert response.status_code == 200
    assert response.json() == {
        "metadata": {"count": 3},
        "accounts": [
            {"id": 1, "username": "account3"},
            {"id": 2, "username": "account2"},
            {"id": 3, "username": "account1"},
        ]
    }


def test_get_account(session, client):
    session.add(DBAccount(username="account1", email="account1@gmail.com",
                hashed_password="I love plaintext pw storing"))
    session.commit()
    response = client.get("/accounts/1")
    assert response.status_code == 200
    assert response.json() == {"id": 1, "username": "account1"}


def test_get_nonexistant_account(session, client):
    response = client.get("/accounts/1")
    assert response.status_code == 404
    assert response.json() == {
        "error": "entity_not_found", "message": "Unable to find account with id=1"}
