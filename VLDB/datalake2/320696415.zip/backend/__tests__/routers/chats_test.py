from sqlmodel import select
from backend.database.schema import DBChat, DBAccount, DBChatMembership, DBMessage
from datetime import datetime


def test_get_chats_in_order(session, client):
    session.add(DBAccount(username="account1", email="account1@gmail.com",
                hashed_password="I love plaintext pw storing"))
    session.add(DBChat(name="CHATNAME", owner_id=1))
    session.add(DBChat(name="CHATNAME2", owner_id=1))
    session.commit()
    response = client.get("/chats")
    assert response.status_code == 200
    assert response.json() == {
        "metadata": {"count": 2},
        "chats": [
            {"id": 1, "name": "CHATNAME", "owner_id": 1},
            {"id": 2, "name": "CHATNAME2", "owner_id": 1},
        ]
    }


def test_get_chats_not_in_order(session, client):
    session.add(DBAccount(username="account1", email="account1@gmail.com",
                hashed_password="I love plaintext pw storing"))
    session.add(DBChat(name="CHATNAME", owner_id=1, id=2))
    session.add(DBChat(name="CHATNAME2", owner_id=1, id=1))
    session.commit()
    response = client.get("/chats")
    assert response.status_code == 200
    assert response.json() == {
        "metadata": {"count": 2},
        "chats": [
            {"id": 1, "name": "CHATNAME2", "owner_id": 1},
            {"id": 2, "name": "CHATNAME", "owner_id": 1},
        ]
    }


def test_get_chat(session, client):
    session.add(DBAccount(username="account1", email="account1@gmail.com",
                hashed_password="I love plaintext pw storing"))
    session.add(DBChat(name="CHATNAME1", owner_id=1, id=1))
    session.commit()
    response = client.get("/chats/1")
    assert response.status_code == 200
    assert response.json() == {"id": 1, "name": "CHATNAME1", "owner_id": 1}


def test_get_nonexistant_chat(session, client):
    response = client.get("/chats/1")
    assert response.status_code == 404
    assert response.json() == {
        "error": "entity_not_found", "message": "Unable to find chat with id=1"}


def test_get_chat_messages_not_inorder(session, client):
    session.add(DBAccount(username="account1", email="account1@gmail.com",
                hashed_password="I love plaintext pw storing"))
    session.add(DBChat(name="CHATNAME", owner_id=1, id=1))
    time = datetime.now()
    session.add(DBMessage(text="second message",
                account_id=1, chat_id=1, created_at=time, id=2))
    session.add(DBMessage(text="first message",
                account_id=1, chat_id=1, created_at=time, id=1))
    session.commit()
    response = client.get("chats/1/messages")
    print(str(time))
    assert response.status_code == 200
    assert response.json() == {
        "metadata": {"count": 2},
        "messages": [
            {"id": 1, "text": "first message", "account_id": 1,
                "chat_id": 1, "created_at": time.isoformat()},
            {"id": 2, "text": "second message", "account_id": 1,
                "chat_id": 1, "created_at": time.isoformat()},

        ]
    }


def test_get_chat_messages_inorder(session, client):
    session.add(DBAccount(username="account1", email="account1@gmail.com",
                hashed_password="I love plaintext pw storing"))
    session.add(DBChat(name="CHATNAME", owner_id=1, id=1))
    time = datetime.now()
    session.add(DBMessage(text="first message",
                account_id=1, chat_id=1, created_at=time))
    session.add(DBMessage(text="second message",
                account_id=1, chat_id=1, created_at=time))
    session.commit()
    response = client.get("chats/1/messages")
    print(str(time))
    assert response.status_code == 200
    assert response.json() == {
        "metadata": {"count": 2},
        "messages": [
            {"id": 1, "text": "first message", "account_id": 1,
                "chat_id": 1, "created_at": time.isoformat()},
            {"id": 2, "text": "second message", "account_id": 1,
                "chat_id": 1, "created_at": time.isoformat()},
        ]
    }


def test_get_nonexistant_chat_messages(session, client):
    response = client.get("/chats/1/messages")
    assert response.status_code == 404
    assert response.json() == {
        "error": "entity_not_found", "message": "Unable to find chat with id=1"}


def test_get_chat_membership_inorder(session, client):
    session.add(DBAccount(username="account1", email="account1@gmail.com",
                hashed_password="I love plaintext pw storing"))
    session.add(DBAccount(username="account2", email="account2@gmail.com",
                hashed_password="I love plaintext pw storing"))
    session.add(DBChat(name="CHATNAME", owner_id=1, id=1))
    session.add(DBChatMembership(chat_id=1, account_id=1))
    session.add(DBChatMembership(chat_id=1, account_id=2))
    response = client.get("chats/1/accounts")
    assert response.status_code == 200
    assert response.json() == {
        "metadata": {"count": 2},
        "accounts": [
            {"id": 1, "username": "account1"},
            {"id": 2, "username": "account2"},
        ]
    }


def test_get_chat_membership_not_inorder(session, client):
    session.add(DBAccount(username="account1", email="account1@gmail.com",
                hashed_password="I love plaintext pw storing"))
    session.add(DBAccount(username="account2", email="account2@gmail.com",
                hashed_password="I love plaintext pw storing"))
    session.add(DBChat(name="CHATNAME", owner_id=1, id=1))
    session.add(DBChatMembership(chat_id=1, account_id=2))
    session.add(DBChatMembership(chat_id=1, account_id=1))
    response = client.get("chats/1/accounts")
    assert response.status_code == 200
    assert response.json() == {
        "metadata": {"count": 2},
        "accounts": [
            {"id": 1, "username": "account1"},
            {"id": 2, "username": "account2"},
        ]
    }


def test_get_nonexistant_chat_membership(session, client):
    response = client.get("/chats/1/accounts")
    assert response.status_code == 404
    assert response.json() == {
        "error": "entity_not_found", "message": "Unable to find chat with id=1"}


def test_post_chat(session, client):
    session.add(DBAccount(username="account1", email="account1@gmail.com",
                          hashed_password="I love plaintext pw storing"))
    request_data = {"name": "hello", "owner_id": 1}
    response = client.post("chats", json=request_data)
    assert response.status_code == 201
    assert response.json() == {"id": 1, ** request_data}


def test_post_chat_no_account(session, client):
    request_data = {"name": "hello", "owner_id": 1}
    response = client.post("chats", json=request_data)
    assert response.status_code == 404
    assert response.json() == {
        "error": "entity_not_found", "message": "Unable to find account with id=1"}


def test_put_chat(session, client):
    session.add(DBAccount(username="account1", email="account1@gmail.com",
                          hashed_password="I love plaintext pw storing"))
    session.add(DBChat(name="hello", owner_id=1))
    request_data = {"name": "hello1"}
    response = client.put("/chats/1", json=request_data)
    assert response.status_code == 200
    assert response.json() == {"id": 1, "owner_id": 1, ** request_data}


def test_put_no_chat(session, client):
    request_data = {"name": "hello1"}
    response = client.put("/chats/1", json=request_data)
    assert response.status_code == 404
    assert response.json() == {
        "error": "entity_not_found", "message": "Unable to find chat with id=1"}


def test_delete_chat(session, client):
    session.add(DBAccount(username="account1", email="account1@gmail.com",
                          hashed_password="I love plaintext pw storing"))
    session.add(DBChat(name="hello", owner_id=1))
    session.add(DBChatMembership(chat_id=1, account_id=1))
    session.add(DBMessage(text="helloworld", account_id=1, chat_id=1))

    response = client.delete("/chats/1")
    assert response.status_code == 204
    response = client.get("/chats/1")
    assert response.status_code == 404
    stmt = select(DBMessage).where(DBMessage.chat_id == 1)
    exc = session.exec(stmt)
    assert exc.first() is None
    stmt2 = select(DBChatMembership).where(DBChatMembership.chat_id == 1)
    exc2 = session.exec(stmt2)
    assert exc2.first() is None


def test_delete_no_chat(session, client):
    response = client.delete("/chats/1")
    assert response.status_code == 404


def test_add_message(session, client):
    session.add(DBAccount(username="account1", email="account1@gmail.com",
                          hashed_password="I love plaintext pw storing"))
    session.add(DBChat(name="hello", owner_id=1))
    session.add(DBChatMembership(chat_id=1, account_id=1))
    body = {"text": "helloworld", "account_id": 1}
    response = client.post("/chats/1/messages", json=body)
    created = session.get(DBMessage, 1).created_at
    assert response.status_code == 201
    assert response.json() == {"id": 1, **body, "chat_id": 1,
                               "created_at": created.isoformat()}


def test_add_message_no_chat(session, client):
    body = {"text": "helloworld", "account_id": 1}
    response = client.post("/chats/1/messages", json=body)
    assert response.status_code == 404
    assert response.json() == {"error": "entity_not_found",
                               "message": "Unable to find chat with id=1"}


def test_update_message(session, client):
    now = datetime.now()
    session.add(DBAccount(username="account1", email="account1@gmail.com",
                          hashed_password="I love plaintext pw storing"))
    session.add(DBChat(name="hello", owner_id=1))
    session.add(DBChatMembership(chat_id=1, account_id=1))
    session.add(DBMessage(text="helloworld",
                account_id=1, chat_id=1, created_at=now))
    body = {"text": "updated"}
    response = client.put("/chats/1/messages/1", json=body)
    assert response.status_code == 200
    assert response.json() == {
        "id": 1,
        "account_id": 1,
        "text": "updated",
        "chat_id": 1,
        "created_at": now.isoformat()
    }


def test_update_no_message(session, client):
    now = datetime.now()
    session.add(DBAccount(username="account1", email="account1@gmail.com",
                          hashed_password="I love plaintext pw storing"))
    session.add(DBChat(name="hello", owner_id=1))
    session.add(DBChatMembership(chat_id=1, account_id=1))
    session.add(DBMessage(text="helloworld",
                account_id=1, chat_id=1, created_at=now))
    body = {"text": "updated"}
    response = client.put("/chats/1/messages/2", json=body)
    assert response.status_code == 404
    assert response.json() == {"error": "entity_not_found",
                               "message": "Unable to find message with id=2"}


def test_update_message_no_chat(session, client):
    body = {"text": "helloworld", "account_id": 1}
    response = client.put("/chats/1/messages/1", json=body)
    assert response.status_code == 404
    assert response.json() == {"error": "entity_not_found",
                               "message": "Unable to find chat with id=1"}


def test_delete_message(session, client):
    session.add(DBAccount(username="account1", email="account1@gmail.com",
                          hashed_password="I love plaintext pw storing"))
    session.add(DBChat(name="hello", owner_id=1))
    session.add(DBChatMembership(chat_id=1, account_id=1))
    session.add(DBMessage(text="helloworld",
                account_id=1, chat_id=1))
    response = client.delete("/chats/1/messages/1")
    assert response.status_code == 204
    assert session.get(DBMessage, 1) is None


def test_delete_no_message(session, client):
    response = client.delete("/chats/1/messages/1")
    assert response.status_code == 404
    assert response.json() == {"error": "entity_not_found",
                               "message": "Unable to find chat with id=1"}


def test_add_account_to_chat(session, client):
    session.add(DBAccount(username="account1", email="account1@gmail.com",
                          hashed_password="I love plaintext pw storing"))
    session.add(DBChat(name="hello", owner_id=1))
    session.add(DBChatMembership(chat_id=1, account_id=1))
    session.add(DBMessage(text="helloworld",
                account_id=1, chat_id=1))
    body = {"account_id": 1}
    response = client.post("/chats/1/accounts", json=body)
    assert response.status_code == 200
    assert response.json() == {"chat_id": 1, "account_id": 1}


def test_add_no_account_to_chat(session, client):
    session.add(DBAccount(username="account1", email="account1@gmail.com",
                          hashed_password="I love plaintext pw storing"))
    session.add(DBChat(name="hello", owner_id=1))
    session.add(DBChatMembership(chat_id=1, account_id=1))
    session.add(DBMessage(text="helloworld",
                account_id=1, chat_id=1))
    body = {"account_id": 2}
    response = client.post("/chats/1/accounts", json=body)
    assert response.status_code == 404
    assert response.json() == {"error": "entity_not_found",
                               "message": "Unable to find account with id=2"}


def test_delete_account_from_chat(session, client):
    session.add(DBAccount(username="account1", email="account1@gmail.com",
                          hashed_password="I love plaintext pw storing"))
    session.add(DBAccount(username="account2", email="account2@gmail.com",
                          hashed_password="I love plaintext pw storing"))

    session.add(DBChat(name="hello", owner_id=1))
    session.add(DBChatMembership(chat_id=1, account_id=1))
    session.add(DBChatMembership(chat_id=1, account_id=2))

    session.add(DBMessage(text="helloworld",
                account_id=2, chat_id=1))

    response = client.delete("/chats/1/accounts/2")
    assert response.status_code == 204
    assert session.get(DBMessage, 1).account_id is None


def test_delete_no_account_from_chat(session, client):
    session.add(DBAccount(username="account1", email="account1@gmail.com",
                          hashed_password="I love plaintext pw storing"))
    session.add(DBAccount(username="account2", email="account2@gmail.com",
                          hashed_password="I love plaintext pw storing"))

    session.add(DBChat(name="hello", owner_id=1))
    session.add(DBChatMembership(chat_id=1, account_id=1))
    session.add(DBChatMembership(chat_id=1, account_id=2))

    session.add(DBMessage(text="helloworld",
                account_id=2, chat_id=1))

    response = client.delete("/chats/3/accounts/1")
    assert response.status_code == 404
    assert response.json() == {"error": "entity_not_found",
                               "message": "Unable to find chat with id=3"}
