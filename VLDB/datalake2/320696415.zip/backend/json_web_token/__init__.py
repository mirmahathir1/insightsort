import os
from dotenv import load_dotenv


load_dotenv()
JWT_SECRET_KEY = os.environ.get("JWT_SECRET_KEY", default="jwt-dev-key")
JWT_ISS = "http://127.0.0.1"
JWT_ALG = "HS256"
JWT_OPTS = {"require_sub": True, "require_iss": True,
            "require_exp": True}
JWT_EXP = 3600
JWT_COOKIE_KEY = "pony_express_token"
