from backend.models import JWTPayload
from jose import jwt
from backend.json_web_token import JWT_ALG, JWT_ISS, JWT_OPTS, JWT_SECRET_KEY


def decode(token: str) -> JWTPayload:
    return JWTPayload(**jwt.decode(token, JWT_SECRET_KEY, algorithms=[JWT_ALG], issuer=JWT_ISS, options=JWT_OPTS))
