from datetime import datetime
from backend.database.schema import DBAccount
from backend.json_web_token import JWT_ALG, JWT_EXP, JWT_ISS, JWT_SECRET_KEY
from backend.models import JWTPayload
from jose import jwt


def create_jwt(user: DBAccount) -> str:
    payload: JWTPayload = JWTPayload(
        sub=str(user.id),  # type: ignore
        iss=JWT_ISS,
        iat=int(datetime.now().timestamp()),
        exp=int(datetime.now().timestamp()) + JWT_EXP
    )
    return jwt.encode(payload.model_dump(), JWT_SECRET_KEY, JWT_ALG)
