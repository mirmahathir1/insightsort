
import bcrypt
from sqlmodel import select
from backend.database.schema import DBAccount
from backend.dependencies import DBSession
from backend.exceptions import AuthFailed, DuplicateEntityValue


def create_user(session: DBSession, username: str, passwordUnhashed: str, email: str) -> DBAccount:
    """ Creates a User

    Args:
        session: the database session
        username: the username
        passwordUnhashed: the password unhashed
        email: the email

    Returns
        DBAccount: the new account

    Raises:
        DuplicateEntityValue: if a user already has the email or the username
    """
    hashed_password = _hash_password(passwordUnhashed)
    if (session.exec(select(DBAccount).where(DBAccount.username == username)).first() is not None):
        raise DuplicateEntityValue(
            type="account", name=username, issue="username")
    if (session.exec(select(DBAccount).where(DBAccount.email == email)).first() is not None):
        raise DuplicateEntityValue(
            type="account", name=email, issue="email")
    user: DBAccount = DBAccount(
        username=username, email=email, hashed_password=hashed_password)
    session.add(user)
    session.commit()
    return user


def verify_password(session: DBSession, username: str, passwordUnhashed: str) -> DBAccount:
    """ Checks if username and given password match with database

    Args:
        session: the database session
        username: the username
        passwordUnhashed: the password unhashed
    Raises:
        AuthFailed: if the user doesn't exist or the password does not match
    """
    user: DBAccount | None = session.exec(
        select(DBAccount).where(DBAccount.username == username)).first()
    print(user)
    if (user is None or not bcrypt.checkpw(passwordUnhashed.encode(), user.hashed_password.encode())):
        raise AuthFailed()
    return user


def update_password(session: DBSession, user: DBAccount, old_pass: str, new_pass: str):
    """Updates the users password

    Args:
        session: the database session
        user: the user
        old_pass: the old password
        new_pass: the new password

    Returns: 
        Nothing

    Raises:
        AuthFailed: If the old pasword was not the same as the old password
    """
    verify_password(session, user.username, old_pass)
    user.hashed_password = _hash_password(new_pass)
    session.commit()


def _hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")
