from sqlmodel import select
from backend.database.schema import DBAccount
from backend.dependencies import DBSession
from backend.exceptions import DuplicateEntityValue, EntityNotFound


def get_all(session: DBSession) -> list[DBAccount]:
    """Retreive all accounts from database

    Args:
        session: the database session
    Returns
        List[DBAccount]: the accounts
    """
    stmt = select(DBAccount)
    results = session.exec(stmt)
    return list(results)


def get_account(session: DBSession, account_id: int) -> DBAccount:
    """Retreive a specific account from database

    Args:
        session: the database session
        account_id: the id of the account to retrieve

    Returns
        DBAccount: the account

    Raises:
        EntityNotFound: If no account with the given id exists
    """

    account = session.get(DBAccount, account_id)
    if account is None:
        raise EntityNotFound("account", account_id)
    return account


def get_list(session: DBSession, ids: list[int]) -> list[DBAccount]:
    """Retreive accounts with the given ids

    Args:
        session: the database session
        ids: the ids of the account to retrieve

    Returns
        DBAccount: the accounts

    Raises:
        EntityNotFound: If no account with the given id exists
    """
    results: list[DBAccount] = []
    for id in ids:
        tmp = session.get(DBAccount, id)
        if tmp is not None:
            results.append(tmp)
    return results


def update_user(session: DBSession, user: DBAccount, username: str | None, email: str | None) -> DBAccount:
    """
    Updates the user

    Args:
        session: the database session
        user: the user to be updated
        username: potential new username
        email: potential new email

    Returns
        DBAccount: the account

    Raises:
        DuplicateEntityValue: if the username or pasword already exists
    """
    if (email is not None):
        stmt = select(DBAccount).where(DBAccount.email == email)
        if (session.exec(stmt).first() is not None):
            raise DuplicateEntityValue(
                type="account", name=email, issue="email")
        user.email = email
    if (username is not None):
        stmt = select(DBAccount).where(DBAccount.username == username)
        if (session.exec(stmt).first() is not None):
            raise DuplicateEntityValue(
                type="account", name=username, issue="username")
        user.username = username
    session.commit()
    return user
