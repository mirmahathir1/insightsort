from sqlmodel import select
from backend.database.schema import DBChat, DBChatMembership, DBMessage
from backend.dependencies import DBSession
from backend.exceptions import ChatMembershipRequired, ChatOwnerRemoval, DuplicateEntityValue, EntityNotFound
from backend.models import AddMembership, CreateChat, CreateMessage, UpdateChat, UpdateMessage
from backend.database import accounts_db


def get_all(session: DBSession) -> list[DBChat]:
    """Retreive all chats from database

    Args:
        session: the database session
    Returns
        DBChats: the chats
    """
    stmt = select(DBChat)
    results = session.exec(stmt)
    return list(results)


def get(session: DBSession, chat_id: int) -> DBChat:
    """Retreive a specific chat from database

    Args:
        session: the database session
        chat_id: the id of the chat to retrieve

    Returns
        DBChat: the chat

    Raises:
        EntityNotFound: If no chat with the given id exists
    """
    chat = session.get(DBChat, chat_id)
    if chat is None:
        raise EntityNotFound("chat", chat_id)
    return chat


def get_messages(session: DBSession, chat_id: int) -> list[DBMessage]:
    """Retreive all messages in a chat from database

    Args:
        session: the database session
        chat_id: the id of the chat to retrieve

    Returns
        DBMessages: the messages

    Raises:
        EntityNotFound: If no chat with the given id exists
    """
    get(session, chat_id)
    stmt = select(DBMessage).where(DBMessage.chat_id == chat_id)
    results = session.exec(stmt)
    return list(results)


def get_chat_member_ids(session: DBSession, chat_id: int) -> list[int]:
    """Retreive all members in a chat from database

    Args:
        session: the database session
        chat_id: the id of the chat to retrieve

    Returns
        ids: the ids of all accounts

    Raises:
        EntityNotFound: If no chat with the given id exists
    """
    get(session, chat_id)
    stmt = select(DBChatMembership.account_id).where(
        DBChatMembership.chat_id == chat_id)
    results = session.exec(stmt)
    return list(results)


def create_chat(session: DBSession, body: CreateChat) -> DBChat:
    """Creates a chat and adds membership relation

    Args:
        session: the database session
        body: the body of the request

    Returns
        DBChat: the newly created chat

    Raises:
        EntityNotFound: If no user with the given id exists
        DuplicateEntityValue: If a chat already has the given name
    """
    accounts_db.get_account(session, body.owner_id)
    _check_if_chat_name_exists(session, body.name)
    chat: DBChat = DBChat(name=body.name, owner_id=body.owner_id)
    session.add(chat)
    session.flush()
    membership: DBChatMembership = DBChatMembership(
        chat_id=chat.id,  # type: ignore
        account_id=body.owner_id
    )
    session.add(membership)
    session.commit()
    return chat


def update_chat(session: DBSession, chat_id: int, body: UpdateChat) -> DBChat:
    """Updates a chat name or owner

    Args:
        session: the database session
        chat_id: the chat to change
        body: the body of the request

    Returns
        DBChat: the newly created chat

    Raises:
        EntityNotFound: If no user with the given id exists
        DuplicateEntityValue: If a chat already has the given name
        ChatMembershipRequired: If a user is set to be the owner that is not currently in the chat
    """
    chat = get(session, chat_id)
    if (body.name is not None):
        _check_if_chat_name_exists(session, body.name, chat_id)
        chat.name = body.name

    if (body.owner_id is not None):
        stmt = select(DBChatMembership.account_id).where(
            DBChatMembership.chat_id == chat_id).where(DBChatMembership.account_id == body.owner_id)
        if (session.exec(stmt).first() is None):
            raise ChatMembershipRequired(body.owner_id, chat_id)
        chat.owner_id = body.owner_id

    session.commit()
    return chat


def delete_chat(session: DBSession, chat_id: int) -> None:
    """Deletes a chat

    Args:
        session: the database session
        chat_id: the chat to delete

    Returns
        Nothing

    Raises:
        EntityNotFound: If no user with the given id exists
    """
    chat = get(session, chat_id)
    session.delete(chat)
    session.commit()


def create_message(session: DBSession, chat_id: int, body: CreateMessage) -> DBMessage:
    """Adds a message to a chat

    Args:
        session: the database session
        chat_id: the chat to add a message to
        body: the message information

    Returns
        DBMessage: the created message

    Raises:
        EntityNotFound: If no chat with the given id exists
        ChatMembershipRequired: If a user is set to be the owner that is not currently in the chat
    """
    chat = get(session, chat_id)
    for member in chat.memberships:
        if member.account_id == body.account_id:
            break
    # Catches if no break was called
    else:
        raise ChatMembershipRequired(body.account_id, chat_id)
    chat.messages.append(DBMessage(
        text=body.text,
        account_id=body.account_id,
        chat_id=chat_id
    ))
    session.commit()
    return chat.messages[len(chat.messages) - 1]


def update_message(session: DBSession, chat_id: int, message_id: int, body: UpdateMessage) -> DBMessage:
    """Updates a message in a chat

    Args:
        session: the database session
        chat_id: the chat to add a message to
        message_id: the message to change
        body: the message information

    Returns
        DBMessage: the updated message

    Raises:
        EntityNotFound: If no chat or message with the given id exists
    """
    get(session, chat_id)
    message = session.get(DBMessage, message_id)
    if message is None or message.chat_id != chat_id:
        raise EntityNotFound("message", message_id)
    message.text = body.text
    session.commit()
    return message


def delete_message(session: DBSession, chat_id: int, message_id: int) -> None:
    """Deletes a message in a chat

    Args:
        session: the database session
        chat_id: the chat to add a message to
        message_id: the message to change

    Returns
        Nothing

    Raises:
        EntityNotFound: If no chat or message with the given id exists
    """
    get(session, chat_id)
    message = session.get(DBMessage, message_id)
    if message is None or message.chat_id != chat_id:
        raise EntityNotFound("message", message_id)
    session.delete(message)
    session.commit()


def add_membership(session: DBSession, chat_id: int, body: AddMembership) -> bool:
    """Adds a member to a chat

    Args:
        session: the database session
        chat_id: the chat to add a member to
        body: the user information

    Returns
        true: if user was not previously a member
        false: if user was already a member

    Raises:
        EntityNotFound: If no chat or user with the given id exists
    """
    chat = get(session, chat_id)
    for member in chat.memberships:
        if member.account_id == body.account_id:
            return False
    accounts_db.get_account(session, body.account_id)
    chat.memberships.append(DBChatMembership(
        account_id=body.account_id,
        chat_id=chat_id))
    session.commit()
    return True


def remove_chat_member(session: DBSession, chat_id: int, account_id: int):
    """Removes a chat member

    Args:
        session: the database session
        chat_id: the chat to remove a message from
        account_id: the account to remove from the chat

    Returns
        Nothing

    Raises:
        EntityNotFound: If no chat with the given id exists
        ChatMembershipRequired: If a user is set to be the owner that is not currently in the chat
        ChatOwnerRemoval: If the user is the owner of the chat
    """
    chat = get(session, chat_id)
    membership = session.get(DBChatMembership, (account_id, chat_id))
    if membership is None:
        raise ChatMembershipRequired(account_id=account_id, chat_id=chat_id)
    if (chat.owner_id == account_id):
        raise ChatOwnerRemoval()
    session.delete(membership)
    stmt = select(DBMessage).where(DBMessage.chat_id ==
                                   chat_id and DBMessage.account_id == account_id)
    accounts = session.exec(stmt)
    for acc in accounts:
        acc.account_id = None
    session.commit()

# Helpers --------------------------------------------------------------------------


def _check_if_chat_name_exists(session: DBSession, chat_name: str, chat_id: int = -1):
    stmt = select(DBChat).where(
        DBChat.name == chat_name).where(DBChat.id != chat_id)
    if (session.exec(stmt).first() is not None):
        raise DuplicateEntityValue("chat", chat_name)
