"""PonyExpress backend API application.

Args:
    app (FastAPI): The FastAPI application
"""

from contextlib import asynccontextmanager

from fastapi import FastAPI, Request

from backend.dependencies import create_db_tables
from backend.exceptions import AccessDenied, AuthFailed, ChatMembershipRequired, ChatOwnerRemoval, DuplicateEntityValue, EntityNotFound, ExpiredJWT, FailedToFindJWT, InvalidJWT
from backend.routers import accounts, auth, chats
from fastapi.middleware.cors import CORSMiddleware


@asynccontextmanager
async def lifespan(app: FastAPI):
    create_db_tables()
    yield


app = FastAPI(
    title="<Pony Express>",
    summary="<Chat App API>",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_methods=["*"],
    allow_headers=["*"],
    allow_credentials=True,
)


@app.get("/status", response_model=None, status_code=204)
def status():
    pass


app.include_router(accounts.router)
app.include_router(chats.router)
app.include_router(auth.router)


@app.exception_handler(EntityNotFound)
async def handle_not_found(request: Request, exception: EntityNotFound):
    return exception.response()


@app.exception_handler(DuplicateEntityValue)
async def handle_duplicate(request: Request, exception: DuplicateEntityValue):
    return exception.response()


@app.exception_handler(ChatMembershipRequired)
async def handle_chat_membership_required(request: Request, exception: ChatMembershipRequired):
    return exception.response()


@app.exception_handler(ChatOwnerRemoval)
async def handle_chat_owner_removal(request: Request, exception: ChatOwnerRemoval):
    return exception.response()


@app.exception_handler(AuthFailed)
async def handle_auth_fail(request: Request, exception: AuthFailed):
    return exception.response()


@app.exception_handler(FailedToFindJWT)
async def handle_failed_to_find_jwt(request: Request, exception: FailedToFindJWT):
    return exception.response()


@app.exception_handler(ExpiredJWT)
async def handle_expired_jwt(request: Request, exception: ExpiredJWT):
    return exception.response()


@app.exception_handler(InvalidJWT)
async def handle_invalid_jwt(request: Request, exception: InvalidJWT):
    return exception.response()


@app.exception_handler(AccessDenied)
async def handle_access_denied(request: Request, exception: AccessDenied):
    return exception.response()
