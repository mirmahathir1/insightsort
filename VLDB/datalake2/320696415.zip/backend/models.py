from typing import Literal, Optional
from pydantic import BaseModel
from datetime import datetime

from backend.database.schema import DBAccount


class Account(BaseModel):
    id: int
    username: str


class AccountAndEmail(BaseModel):
    id: int
    username: str
    email: str


class Metadata(BaseModel):
    count: int


class AccountCollection(BaseModel):
    accounts: list[Account]
    metadata: Metadata


class Chat(BaseModel):
    id: int
    owner_id: int
    name: str


class ChatCollection(BaseModel):
    metadata: Metadata
    chats: list[Chat]


class Message(BaseModel):
    id: int
    text: str
    account_id: int | None
    chat_id: int
    created_at: datetime


class MessageCollection(BaseModel):
    messages: list[Message]
    metadata: Metadata


def accounts_to_collection(dbAccounts: list[DBAccount]):
    accs: list[Account] = []
    for acc in dbAccounts:
        if acc.id is not None:
            accs.append(Account(id=acc.id, username=acc.username))
    ret: AccountCollection = AccountCollection(
        accounts=accs, metadata=Metadata(count=len(accs)))
    return ret


class CreateChat(BaseModel):
    name: str
    owner_id: int


class UpdateChat(BaseModel):
    name: Optional[str] = None
    owner_id: Optional[int] = None


class CreateMessage(BaseModel):
    text: str
    account_id: int


class UpdateMessage(BaseModel):
    text: str


class AddMembership(BaseModel):
    account_id: int


class AddMembershipOK(BaseModel):
    chat_id: int
    account_id: int


class AddMembershipCreated(BaseModel):
    chat_id: int
    account_id: int


class AddMembershipResponse(BaseModel):
    chat_id: int
    account_id: int


class AccountCreated(BaseModel):
    id: int
    username: str
    email: str


class CreateAccount(BaseModel):
    username: str
    email: str
    password: str


class UpdateAccount(BaseModel):
    username: Optional[str] = None
    email: Optional[str] = None


class UpdatePassword(BaseModel):
    old_password: str
    new_password: str


class LoginWithUserAndPass(BaseModel):
    username: str
    password: str


class JWTBearer(BaseModel):
    access_token: str
    token_type: Literal['bearer'] = 'bearer'


class JWTPayload(BaseModel):
    sub: str
    iss: str
    iat: int
    exp: int
