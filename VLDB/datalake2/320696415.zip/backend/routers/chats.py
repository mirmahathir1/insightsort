from fastapi import APIRouter, Response
from backend.database import chats_db, accounts_db
from backend.database.schema import DBChat, DBMessage

from backend.exceptions import AccessDenied, ChatMembershipRequiredResponse, ChatOwnerRemovalResponse, EntityNotFoundResponse, DuplicateEntityValueResponse, JWTIssueResponse
from backend.models import AccountCollection, AddMembership, AddMembershipCreated, AddMembershipOK, AddMembershipResponse, Chat, ChatCollection, CreateMessage, Message, MessageCollection, Metadata, UpdateChat, accounts_to_collection, CreateChat, UpdateMessage
from backend.dependencies import DBSession
from backend.routers.authenticated_route import AuthenticatedRoute

router = APIRouter(prefix="/chats", tags=["Chats"])


@router.post("",
             status_code=201,
             response_model=Chat,
             responses={404: {"model": EntityNotFoundResponse},
                        422: {"model": DuplicateEntityValueResponse},
                        403: {"model": JWTIssueResponse}})
def add_chat(session: DBSession, body: CreateChat, user: AuthenticatedRoute) -> DBChat:
    if (user.id != body.owner_id):
        raise AccessDenied("chat")
    return chats_db.create_chat(session, body)


@router.get("", response_model=ChatCollection)
def get_chats(session: DBSession) -> ChatCollection:
    """Gets all of the different chats"""
    chatsDB: list[DBChat] = chats_db.get_all(session)
    chats: list[Chat] = []
    for chat in chatsDB:
        if chat.id is not None:
            chats.append(
                Chat(id=chat.id, owner_id=chat.owner_id, name=chat.name))
    chats.sort(key=lambda c: c.id)
    ret: ChatCollection = ChatCollection(
        chats=chats,
        metadata=Metadata(count=len(chats))
    )
    return ret


@router.get("/{chat_id}", response_model=Chat, responses={404: {"model": EntityNotFoundResponse}})
def get_chat(session: DBSession, chat_id: int) -> DBChat:
    """Gets a specific chat"""
    chat = chats_db.get(session, chat_id)
    return chat


@router.put("/{chat_id}",
            response_model=Chat,
            responses={404: {"model": EntityNotFoundResponse},
                       422: {"model": DuplicateEntityValueResponse | ChatMembershipRequiredResponse}})
def update(session: DBSession, chat_id: int, body: UpdateChat) -> DBChat:
    return chats_db.update_chat(session, chat_id, body)


@router.delete("/{chat_id}", status_code=204, responses={404: {"model": EntityNotFoundResponse}})
def delete(session: DBSession, chat_id: int):
    chats_db.delete_chat(session, chat_id)


@router.get("/{chat_id}/messages", response_model=MessageCollection, responses={404: {"model": EntityNotFoundResponse}})
def get_messages(session: DBSession, chat_id: int) -> MessageCollection:
    """Returns the messages in a chat"""
    messagesDB = chats_db.get_messages(session, chat_id)
    messages: list[Message] = []
    for m in messagesDB:
        if m.id is not None and m.created_at is not None:
            messages.append(Message(
                id=m.id,
                text=m.text,
                account_id=m.account_id,
                chat_id=m.chat_id,
                created_at=m.created_at))

    messages.sort(key=lambda m: m.id)
    ret: MessageCollection = MessageCollection(
        messages=messages, metadata=Metadata(count=len(messages)))
    return ret


@router.post("/{chat_id}/messages",
             status_code=201,
             response_model=Message,
             responses={404: {"model": EntityNotFoundResponse},
                        422: {"model": ChatMembershipRequiredResponse},
                        403: {"model": JWTIssueResponse}
                        })
def create_message(session: DBSession, chat_id: int, body: CreateMessage, user: AuthenticatedRoute) -> DBMessage:
    if (user.id != body.account_id):
        raise AccessDenied("message")
    return chats_db.create_message(session, chat_id, body)


@router.put("/{chat_id}/messages/{message_id}",
            response_model=Message,
            responses={404: {"model": EntityNotFoundResponse}})
def update_message(session: DBSession, chat_id: int, message_id: int, text: UpdateMessage) -> DBMessage:
    return chats_db.update_message(session, chat_id, message_id, text)


@router.delete("/{chat_id}/messages/{message_id}",
               status_code=204,
               responses={404: {"model": EntityNotFoundResponse}})
def delete_message(session: DBSession, chat_id: int, message_id: int) -> None:
    chats_db.delete_message(session, chat_id, message_id)


@router.get("/{chat_id}/accounts", response_model=AccountCollection, responses={404: {"model": EntityNotFoundResponse}})
def get_accounts_in_chat(session: DBSession, chat_id: int) -> AccountCollection:
    """Gets the accounts in a chat"""
    ids = chats_db.get_chat_member_ids(session, chat_id)
    accountsDB = accounts_db.get_list(session, ids)
    ret = accounts_to_collection(accountsDB)
    ret.accounts.sort(key=lambda acc: acc.id)
    return ret


@router.post("/{chat_id}/accounts",
             responses={200: {"model": AddMembershipOK},
                        201: {"model": AddMembershipCreated},
                        404: {"model": EntityNotFoundResponse}})
def add_account_to_chat(response: Response, session: DBSession, chat_id: int, body: AddMembership) -> AddMembershipResponse:
    if (chats_db.add_membership(session, chat_id, body)):
        response.status_code = 201
    return AddMembershipResponse(chat_id=chat_id, account_id=body.account_id)


@router.delete("/{chat_id}/accounts/{account_id}",
               status_code=204,
               responses={
                   404: {"model": EntityNotFoundResponse},
                   422: {"model": ChatMembershipRequiredResponse | ChatOwnerRemovalResponse}
               }
               )
def remove_account_from_chat(session: DBSession, chat_id: int, account_id: int):
    chats_db.remove_chat_member(session, chat_id, account_id)
