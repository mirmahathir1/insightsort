from datetime import datetime
from typing import Annotated
from fastapi import Depends
from fastapi.security import APIKeyCookie, HTTPAuthorizationCredentials, HTTPBearer
from jose import ExpiredSignatureError
from backend.json_web_token import JWT_COOKIE_KEY, JWT_EXP, decode
from backend.dependencies import DBSession
from backend.exceptions import ExpiredJWT, FailedToFindJWT, InvalidJWT
from backend.database import accounts_db
from backend.database.schema import DBAccount


cookie_scheme = APIKeyCookie(name=JWT_COOKIE_KEY, auto_error=False)
bearer_scheme = HTTPBearer(auto_error=False)


def get_access_token(
    cookie_token: str | None = Depends(cookie_scheme),
    bearer_token: HTTPAuthorizationCredentials | None = Depends(bearer_scheme)
) -> str:
    if cookie_token is not None:
        return cookie_token
    elif bearer_token is not None:
        return bearer_token.credentials
    raise FailedToFindJWT()


def get_current_user(session: DBSession, token: str = Depends(get_access_token)) -> DBAccount:
    try:
        payload = decode.decode(token)
    except ExpiredSignatureError:
        raise ExpiredJWT()
    except:
        raise InvalidJWT()
    return accounts_db.get_account(session, int(payload.sub))


AuthenticatedRoute = Annotated[DBAccount, Depends(get_current_user)]
