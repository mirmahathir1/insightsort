from typing import Annotated
from fastapi import APIRouter, Depends, Form, Response
from backend.database import auth_db
from backend.exceptions import AuthFailedResponse, DuplicateEntityValueResponse, JWTIssueResponse
from backend.models import AccountCreated, CreateAccount, JWTBearer, LoginWithUserAndPass
from backend.dependencies import DBSession
from backend.json_web_token import JWT_COOKIE_KEY
from backend.json_web_token.create import create_jwt
from backend.routers.authenticated_route import AuthenticatedRoute, get_current_user


router = APIRouter(prefix="/auth", tags=["Authentication"])


@router.post("/registration", response_model=AccountCreated, status_code=201, responses={422: {"model": DuplicateEntityValueResponse}})
def create_account(session: DBSession, body: Annotated[CreateAccount, Form()]):
    """A new account in the database"""
    return auth_db.create_user(session, body.username, body.password, body.email)


@router.post("/token", response_model=JWTBearer, status_code=200, responses={401: {"model": AuthFailedResponse}})
def get_token(session: DBSession, body: Annotated[LoginWithUserAndPass, Form()]):
    """An access token (JWT) for the requesting account """
    user = auth_db.verify_password(session, body.username, body.password)
    return JWTBearer(access_token=create_jwt(user))


@router.post("/web/login", status_code=204, responses={401: {"model": AuthFailedResponse}})
def get_cookie(response: Response, session: DBSession, body: Annotated[LoginWithUserAndPass, Form()]):
    """An access token (JWT) for the requesting account is stored in cookie"""
    user = auth_db.verify_password(session, body.username, body.password)
    token = create_jwt(user)
    response.set_cookie(JWT_COOKIE_KEY, token, httponly=True)


@router.post("/web/logout", status_code=204, responses={403: {"model": JWTIssueResponse}})
def logout(response: Response, session: DBSession, user: AuthenticatedRoute):
    """A logged-in account is logged out"""
    response.delete_cookie(JWT_COOKIE_KEY)
