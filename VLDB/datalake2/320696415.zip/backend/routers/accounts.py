from typing import Annotated
from fastapi import APIRouter, Form
from backend.database import accounts_db, auth_db
from backend.database.schema import DBAccount
from backend.exceptions import AuthFailedResponse, ChatOwnerRemoval, ChatOwnerRemovalResponse, EntityNotFoundResponse, JWTIssueResponse
from backend.models import Account, AccountAndEmail, AccountCollection, UpdateAccount, UpdatePassword, accounts_to_collection
from backend.dependencies import DBSession
from backend.routers.authenticated_route import AuthenticatedRoute

router = APIRouter(prefix="/accounts", tags=["Accounts"])


@router.get("", response_model=AccountCollection)
def get_accounts(session: DBSession) -> AccountCollection:
    """Gets a list of all accounts"""
    dbAccounts: list[DBAccount] = accounts_db.get_all(session)
    ret = accounts_to_collection(dbAccounts)
    ret.accounts.sort(key=lambda acc: acc.id)
    return ret


@router.get("/me", response_model=AccountAndEmail, status_code=200, responses={403: {"model": JWTIssueResponse}})
def get_me(session: DBSession, user: AuthenticatedRoute):
    """Retrieves the account data for an authenticated account"""
    return user


@router.put("/me", response_model=AccountAndEmail, status_code=200, responses={403: {"model": JWTIssueResponse}})
def put_me(session: DBSession, user: AuthenticatedRoute, body: UpdateAccount):
    """The authenticated account is updated"""
    return accounts_db.update_user(session, user, body.username, body.email)


@router.delete("/me", status_code=204, responses={403: {"model": JWTIssueResponse}, 422: {"model": ChatOwnerRemovalResponse}})
def delete_user(session: DBSession, user: AuthenticatedRoute):
    """The authenticated account is deleted"""
    if (len(user.owned_chats) != 0):
        raise ChatOwnerRemoval()
    session.delete(user)
    session.commit()
    pass


@router.put("/me/password", status_code=204, responses={403: {"model": JWTIssueResponse}, 401: {"model": AuthFailedResponse}})
def put_password(session: DBSession, user: AuthenticatedRoute, body: Annotated[UpdatePassword, Form()]):
    """The password of an authenticated account is updated """
    auth_db.update_password(
        session, user, body.old_password, body.new_password)


@router.get("/{account_id}", response_model=Account, responses={404: {"model": EntityNotFoundResponse}})
def get_account(session: DBSession, account_id: int) -> DBAccount:
    """Gets a specific account"""
    account = accounts_db.get_account(session, account_id)
    return account
