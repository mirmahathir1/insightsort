from fastapi import Response
from fastapi.exceptions import HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel


class EntityNotFoundResponse(BaseModel):
    error: str
    message: str


class EntityNotFound(HTTPException):
    def __init__(self, name: str, id: int):
        self.status_code: int = 404
        self.detail = EntityNotFoundResponse(
            error="entity_not_found",
            message=f"Unable to find {name} with {id=}",
        )

    def response(self) -> Response:
        return JSONResponse(
            status_code=self.status_code,
            content=self.detail.model_dump(mode="json")
        )


class DuplicateEntityValueResponse(BaseModel):
    error: str
    message: str


class DuplicateEntityValue(HTTPException):
    def __init__(self, type: str, name: str, issue: str = "name"):
        self.status_code = 422
        self.detail = DuplicateEntityValueResponse(
            error="duplicate_entity_value",
            message=f"Duplicate value: {type} with {issue}={name} already exists"
        )

    def response(self) -> Response:
        return JSONResponse(
            status_code=self.status_code,
            content=self.detail.model_dump(mode="json")
        )


class ChatMembershipRequiredResponse(BaseModel):
    error: str
    message: str


class ChatMembershipRequired(HTTPException):
    def __init__(self, account_id: int, chat_id: int):
        self.status_code = 422
        self.detail = ChatMembershipRequiredResponse(
            error="chat_membership_required",
            message=f"Account with id={account_id} must be a member of chat with id={chat_id}"
        )

    def response(self) -> Response:
        return JSONResponse(
            status_code=self.status_code,
            content=self.detail.model_dump(mode="json")
        )


class ChatOwnerRemovalResponse(BaseModel):
    error: str
    message: str


class ChatOwnerRemoval(HTTPException):
    def __init__(self):
        self.status_code = 422
        self.detail = ChatOwnerRemovalResponse(
            error="chat_owner_removal",
            message="Unable to remove the owner of a chat"
        )

    def response(self) -> Response:
        return JSONResponse(
            status_code=self.status_code,
            content=self.detail.model_dump(mode="json")
        )


class AuthFailedResponse(BaseModel):
    error: str
    message: str


class AuthFailed(HTTPException):
    def __init__(self):
        self.status_code = 401
        self.detail = AuthFailedResponse(
            error="invalid_credentials",
            message="Authentication failed: invalid username or password"
        )

    def response(self) -> Response:
        return JSONResponse(
            status_code=self.status_code,
            content=self.detail.model_dump(mode="json")
        )


class JWTIssueResponse(BaseModel):
    error: str
    message: str


class FailedToFindJWT(HTTPException):
    def __init__(self):
        self.status_code = 403
        self.detail = JWTIssueResponse(
            error="authentication_required",
            message="Not authenticated"
        )

    def response(self) -> Response:
        return JSONResponse(
            status_code=self.status_code,
            content=self.detail.model_dump(mode="json")
        )


class ExpiredJWT(HTTPException):
    def __init__(self):
        self.status_code = 403
        self.detail = JWTIssueResponse(
            error="expired_access_token",
            message="Authentication failed: expired access token"
        )

    def response(self) -> Response:
        return JSONResponse(
            status_code=self.status_code,
            content=self.detail.model_dump(mode="json")
        )


class InvalidJWT(HTTPException):
    def __init__(self):
        self.status_code = 403
        self.detail = JWTIssueResponse(
            error="invalid_access_token",
            message="Authentication failed: invalid access token"
        )

    def response(self) -> Response:
        return JSONResponse(
            status_code=self.status_code,
            content=self.detail.model_dump(mode="json")
        )


class AccessDeniedResponse(BaseModel):
    error: str
    message: str


class AccessDenied(HTTPException):
    def __init__(self, type):
        self.status_code = 403
        self.detail = JWTIssueResponse(
            error="access_denied",
            message=f"Cannot create {type} on behalf of different account"
        )

    def response(self) -> Response:
        return JSONResponse(
            status_code=self.status_code,
            content=self.detail.model_dump(mode="json")
        )
