import { ChatList } from "./ChatList";
import { Chat } from "./Chat";
export function ChatLayout() {
    return <>
    <div className="flex flex-row w-full h-[calc(100%-4rem)]">
        <ChatList />
        <Chat />
    </div>

    </>
}