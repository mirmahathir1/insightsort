import { useQuery } from "@tanstack/react-query"
import { useParams } from "react-router"
const baseAPIUrl = import.meta.env.VITE_API_URL ?? "https://localhost:8000"

type Message = {
    id: number
    text: string
    account_id?: number
    chat_id: number
    created_at: string
}

function getUsernameByID(accounts: Account[], id?: number): string {
    if(!id) return "[undefined]"
    for(let account of accounts) {
        if(id === account.id)
            return account.username
    }
    return "[undefined]"
}

type Account = {
    id: number
    username: string
}
type Accounts = {
    accounts: Account[]
}
function ChatMessage({id, text, account_id, chat_id, created_at}: Message) {
    const {isLoading, data } = useQuery<Accounts>({
        queryKey: [`chat-accounts-${chat_id}`],
        queryFn: async () => {
            const response = await fetch(`${baseAPIUrl}/chats/${chat_id}/accounts`)
            const data = await response.json()
            if(!response.ok)
                throw new Error(data.message)
            return data
         }
    }) 
    if(isLoading) {
        return <p>Loading Chats...</p>
    }

    let date = new Date(created_at)
    return <div className="w-3/4 border-1 border-gray-400 p-2 flex flex-col"
    >
        <div className="flex justify-between">
            <p>{getUsernameByID(data!.accounts, account_id)}</p>
            <p>{date.toDateString() + " " + date.toLocaleTimeString()}</p>
        </div>
        <div className=""><p>{text}</p></div>
    </div>
}

type ChatMessages = {
    messages: Message[]
}
export function Chat() {
    const { chatId } = useParams<{ chatId?: string }>();
    if(!chatId) return 
    const {isLoading, error, data } = useQuery<ChatMessages>({
        queryKey: [`chat-messages-${chatId}`],
        queryFn: async () => {
            const response = await fetch(`${baseAPIUrl}/chats/${chatId}/messages`)
            const data = await response.json()
            if(!response.ok)
                throw new Error(data.message)
            return data
         }
    }) 
    if(isLoading) return <p>Loading...</p>
    if(error) return <p>{error.message}</p>
    data!.messages.sort((a, b) => {
        return new Date(a.created_at).getTime() - new Date(b.created_at).getTime()
    })
        
    
    return <div className="w-full overflow-y-scroll h-full flex flex-col items-center gap-4 py-4"
    >
        {data!.messages.map((message) => {
            return <ChatMessage key={message.id} {...message} />
        })}
    </div>
}