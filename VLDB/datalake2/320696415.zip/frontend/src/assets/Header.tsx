
export function Header() {
    return <>
    <header className="h-16 w-full flex flex-row p-4 bg-gray-700">
        <h1 className="text-gray-50 text-4xl self-center"><a href="/">Pony Express</a></h1> 
    </header>
    </> 


}