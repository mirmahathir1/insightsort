import { useQuery } from "@tanstack/react-query";
import { useParams } from "react-router"
const baseAPIUrl = import.meta.env.VITE_API_URL ?? "https://localhost:8000"

type ChatLinkProps = {
    name: string;
    linkID: number;
}

function ChatLink({name, linkID}: ChatLinkProps) {
    let classes = "text-3xl hover:bg-gray-700 hover:underline border-bottom-1 border-b-1 px-4"
    const { chatId } = useParams<{ chatId?: string }>();
    if(chatId && chatId === linkID.toString()) {
        classes += " bg-gray-700 font-weight-bold"
    }
    let link = `/chats/${linkID}`
    return <a href={link} className={classes}>{name}</a>
}

type Chat = {
    id: number
    owner_id: number
    name: string
}

type Chats = {
    chats: Chat[]
}
export function ChatList() {
    const {isLoading, error, data} = useQuery<Chats>({
        queryKey: ['chat-list'],
        queryFn: async () => {
            const response = await fetch(`${baseAPIUrl}/chats`)
            const data = await response.json()
            if(!response.ok)
                throw new Error(data.message)
            return data as Chats
        }
    })
    if(error) return <p>Error: {error.message}</p>
    if(isLoading) return <p>Loading...</p>
    data!.chats.sort((a, b) => a.name.localeCompare(b.name))
    return <nav className="w-90 flex flex-col gap-4 text-gray-50 bg-blue-950 h-full pt-4">
        {data!.chats.map((chat) => {
            return <ChatLink key={chat.id} linkID={chat.id} name={chat.name} />
        })}
    </nav>
}